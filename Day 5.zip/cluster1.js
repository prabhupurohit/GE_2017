var cluster = require('cluster');  
var http    = require('http');  
var os      = require('os');
var numCPUs = os.cpus().length;

if (cluster.isMaster) {  
  for (var i = 0; i < numCPUs; ++i) {
    cluster.fork();
  }
  Object.keys(cluster.workers).forEach(function(id) {
    console.log("I am running with ID : "
    	+ cluster.workers[id].process.pid);
  });

  cluster.on('exit', function(worker, code, signal) {
    console.log('worker ' + worker.process.pid + ' died');
  });
} 

else {
  http.createServer(function(req, res) {
 			 res.end("hello world " +process.pid);
   		console.log("hello world from " +process.pid);
   }).listen(8080);
}

