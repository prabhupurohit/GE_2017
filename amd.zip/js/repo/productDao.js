define(["model/products"],function(Product) {
	var products = [];

	function init() {
			products.push(new Product(1,"A"));
			products.push(new Product(2,"B"));
	};
	function getAll() {
			return products;
	};

	return {
		init: init,
		get: getAll
	}
});