(function() {
    var ng = angular.module("customer_module", ["customer_service","custom_directives"]);

    ng.controller("CustomerMenuController", function($rootScope,$scope){
    	$scope.searchText = "";
    	$scope.filterCustomers = function() {
    		$rootScope.$broadcast("filter_event",$scope.searchText);
    	}
    });

    ng.controller("CustomerListController", function($scope,CustomerService) {
    	CustomerService.getCustomers().then(function(response){
    		$scope.customers = customers = response.data;
    	});
    	

    	$scope.$on("filter_event", function(evt , txt){
    		var result = [];
    		customers.forEach(function(c){
    			if(c.firstName.toUpperCase().indexOf(txt.toUpperCase()) >=0
    				|| c.lastName.toUpperCase().indexOf(txt.toUpperCase()) >=0	) {
    				result.push(c);
    			}
    		});
    		$scope.customers = result;

    	});

    	$scope.editForm = function(customer) {
    		$scope.currentCustomer = customer;
    		$scope.editMode = true;
    	}

    	$scope.update = function() {
    		// send the current customer to backend for update
    		$scope.editMode = false;
    	}

    	$scope.deleteCustomer = function(id) {
    		var idx = -1;
    		$scope.customers.forEach(function(c,index){
    			if(c.id == id) {
    				idx = index;
    			}
    		});
    		if( idx >=0 ){
    			// REST call to delete
    			$scope.customers.splice(idx, 1);
    			CustomerService.deleteCustomer(id);
    		}
    	}
    });

   /* var customers = [
        { "id": 1, "firstName": "Ross", "lastName": "Geller", "gender": "male", "address": "NY" },
        { "id": 2, "firstName": "Joey", "lastName": "Tribuanni", "gender": "male", "address": "NY" },
        { "id": 3, "firstName": "Monica", "lastName": "Geller", "gender": "female", "address": "NY" },
        { "id": 4, "firstName": "Rachel", "lastName": "Green", "gender": "female", "address": "NY" },
        { "id": 5, "firstName": "Chandler", "lastName": "Bing", "gender": "male", "address": "NY" },
        { "id": 6, "firstName": "Phoebe", "lastName": "Buffay", "gender": "female", "address": "NY" }
    ];*/
})();
