(function(){
	angular.module("custom_directives",[])
	.directive("cardView", function() {
		return {
			restrict: 'E',
			templateUrl :'app/templ/card.html',
			scope : {
				first: '=',
				second : '=',
				info : '=',
				pic : '=',
				delete : '&',
				editForm : '&'
			}
		}
	});
})();