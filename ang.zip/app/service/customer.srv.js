(function(){
	var ng = angular.module("customer_service",[]);
	ng.service("CustomerService", function($http, $q){
		this.getCustomers = function() {
			var url = "http://localhost:3000/api/customers/";
			var deferred = $q.defer();
			$http.get(url).then(function(data){
				deferred.resolve(data);
			},
			function(data){
				deferred.reject(data);
			});

			return deferred.promise;
		}

		this.deleteCustomer = function(id) {
			var url = "http://localhost:3000/api/customers/";
			$http.delete(url + id);
		}
	});
})();