// customer-spec.js
describe('Customer Demo App', function() {
  var customerList = element.all(by.repeater('customer in customers'));
 
  beforeEach(function() {
    browser.get('http://localhost:3000/c1.html');
  });

  it('should have six customers', function() {
    expect(customerList.count()).toEqual(6);  
  });

   it('should delete a customer', function() {
      customerList.get(1).element(by.css('.cardClose')).click();
      expect(customerList.count()).toEqual(5);  
    });

  it('should filter customers', function() {
      element(by.model('searchText')).sendKeys("Geller");
      browser.pause();
      expect(customerList.count()).toEqual(2);  
  });
});