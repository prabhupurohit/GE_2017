var mongoose = require('mongoose');

// JavaScript to MongoDB Document mapping
var CustomerSchema = new mongoose.Schema({
	"id": Number,
	"firstName" : String,
	"lastName" : String,
	"gender" : String,
	"address" : String
});

var Customers = mongoose.model("customers", CustomerSchema);

module.exports = Customers;
