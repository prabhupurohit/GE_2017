NodeJS

Event Driven:
console.log("Start");

function sample() {
		setTimeout(function() {
			console.log("Hello !!!")
		}, 2000);
}

function doTask() {
		setInterval(function() {
			console.log("Hi !!!")
		}, 500);
}

sample();
doTask();
console.log("Bye!!!");

--------
Install NodeJS

Why NodeJS?
	Event Driven, non-blocking IO

Why People are moving to NodeJS?
 1) Paypal
 	Productivity , Performance
 2) Walmart
 	2014 Blackfriday
 3) LinkedIn

 Where can i Use nodeJS?
 	1) nonBlocking IO
 		netflix
 	2) SPA
 	3) Dashboard
-----------------------------------

ES6 ES2015 features:

1) supports block level variables and constants
let and const are block level scope

function test() {
		if( cond ) {
			let x = 10;
			const PI = 3.14159;
		}
}

2) Arrow Operator

var add = function(x, y) {
		return x + y;
}


var sub = (x,y) => { return x - y; }

var sub = (x,y) => x - y ;

3) New String literal:  ` `

var style = {
	width:'200px',
	height:'400px',
	color:'red'
}


var el = `<div>
			<p style="width:${style.width}; height: ${style.height}">
				Hello World
			</p>
	</div>`;


4) introduced class

5) Promise API

Sync call

var result = doTask();
next line

With Promise API

doTask().then(function() { }, function error() { });
-------------------------------------------------------------------------

Benchmark:
ab -n 1000 -c 100 http://localhost:3000/

-------------------------------------

REPL
	ReadEvalPrintLoop
-----------------------------------
fs, http, repl, net, cluster, os modules:

nodeJS uses CommonModuleJS

Module Pattern:
a.js
(function() { })();

b.js
(function() { })();

html needs them
<script src ="a.js"></script>
<script src ="b.js"></script>

Asynchronous Module loading
a) RequireJS
b) CommonJS
c) SystemJS

Node JS CommonJS for AMD

a.js

exports.add = function() {
	
}

exports.test = function test() {
	
}


b.js
if(x){
	var test = require('./a').test;
}
var add = require('./a').add;


var sdf = require('./a').add;

-----

NPM -- > node package manager
	to create, publish and import node packages

 npm uses package.json for package maangement:

 package.json

 {
 	"name":
 	"author":

 	"dependencies": {
 		"mysql" : "3.1.15",
 		"blue-bird": "^2.1.1",
 		"passport" : "~2.0.1"
 	}
 }

 JavaScript and unit testing

 Unit testing frameworks:
 1) JASMINE
 	Prefer for client side
 2) MOCHA
 	Prefer for server side

 Testing is all about AAA's
 Assemble Action Assert

MOCHA provides framework for Assemble and Action and execute tests, it does not contain assertion library

Some of the assertion libraries available are:
chai
shouldjs 


converter:/> npm install --save-dev mocha chai request

installs into node_modules folder

npm i -g mocha

mocha --reporter spec

npm config set proxy http://proxy.company.com:8080
npm config set https-proxy http://proxy.company.com:8080

------------------------------------

MongoDB Humungous Database is a NoSQL database

RDBMS 										MongoDB
Database 								Database
Tables 									Collections
Row 									Document
columns 								fields
										BSON [Binary Script Object notation]

1) Start Mongodb database server

$ mongod --dbpath ./data

2) Import JSON data into mongodb

$ mongoimport --file customers.json --db my_db --collection customers --drop

3) Open MongoDB Shell for executing mongo db commands using cli

$ mongo
> use my_db
> db.<collection>.find()

Example:
> db.customers.find().pretty()

Where clause: select * from customers where gender like 'female'
> db.customers.find({"gender":"female"}).pretty()
Where clause: select * from customers where gender like 'female' and address like 'NY'
> db.customers.find({"gender":"female","address":"NY"}).pretty()

Scalar values

Where clause: select firstName,gender from customers 
> db.customers.find({}, {"firstName":1, "gender" : 1}).pretty()

Where clause: select all except address from customers 

> db.customers.find({}, {"address":0}).pretty()

> db.customers.find({"$or": {gender":"female", "lastName":"Geller"} }).pretty()

-----------------------------

> db.insertOne({json data})

> db.insertMany(many json objects)


-------------------- 

NODEJS <---  DRIVERS [ Integration APIs]   ---> MongoDB

NODEJS <---   Mongoose [ ODM ]---> MongoDB

-----------------------------------------------------------

	Building Web Applications and RESTful services

	Express is a Framework executes on nodeJS environment

	Express can be used to build traditional web application or REST services


	 traditional web application : Server contains various templates,
	 reads dynamic data, renders it and sends HTML as response

	 Templates for Server Side:
	 1) ASP.NET
	 2) JSP
	 3) PHP

	 JS provides various Templates for rendering dynamic data:

	 1) Underscore  _.each()
	 2) Mustache  {{firstName}}
	 3) Handlebars  #firstName
	 4) EJS [ Server -side] <%= firstName %>
	 5) JADE [ Server -side]
	 6) jQuery

	 Express by default uses JADE as a template

	 ---------

	 $ npm i -g express express-generator

---------------------------------------------------------------------


	EXPRESS Project [ Simples development of Web applicaiton]

	1) app.js
		is a place where the following are configured
		a) routes
		b) views

	npm start [ node ./bin/www.js]

	Flow:

	http://localhost:3000/customers

	1) checks in app.js
		app.use('/customers',customers);

	2) this maps to 
		var customers = require('./routes/customers');

	3) In routes folder [customers.js]
		require('./model/customer');
		this loads customer.js from model folder
		which intern creates a customer model [Customers] and exports

		res.render('customers', {JSON DATA});

		this looks for views/customers.js file
		to that file JSON data is passed

		File is compiled , HTML is created and sent to Broswer


	4) In app.js
		moongoose.connect(...) to connect to DB

--------------------
	Express for RESTful webservices

	A Resource residing in server can be served using various representation

	REPRESENTATION: JSON, XML, ATOM, RSS feed

	Represetnational State Transfer

	works with "http" protocol

	a) URI is used to identify the resource
	b) HTTP method is used to identify the action

	Examples:

	1)	GET
		http://localhost:3000/api/customers

		gets all customers from server,
		representation depends on "accept" MIME type of client

		"accept": "application/json"

	2) GET
		http://localhost:3000/api/customers/2

		Extra Path parameter should be ID
		gets  customer with id 1 from server,
		representation depends on "accept" MIME type of client

		"accept": "application/json"

	3) GET
		http://localhost:3000/api/customers?gender=female

		Query String is based on criteria other than id [ Sublist]

		gets all customers for server,
		representation depends on "accept" MIME type of client

		"accept": "application/json"


	4) POST
		http://localhost:3000/api/customers

		Payload contains the data to be added to resource

		"content-type": "application/json"

	5) PUT
		http://localhost:3000/api/customers/2

		Payload contains the new data to be updated to resource 2

		"content-type": "application/json"

	6) DELETE
		POST
		http://localhost:3000/api/customers/2

	7) PATCH
		http://localhost:3000/api/customers/2

		Payload contains the data to be added to resource

		"content-type": "application/json"
--------------------------------------------------------------

	jQuery
		library
		Why? simplifies DOM Manipulation, DOM Traverse, AJAX [XMLHttpRequest]
	