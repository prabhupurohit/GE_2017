var express = require('express');
var router = express.Router();
var Customers = require('../model/customer');

/* GET Customer home page. [http://localhost:3000/customers] */
router.get('/customers', function(req, res, next) {
	Customers.find({},function(err, docs){
		if(!err) {
			 res.json(docs);
		}
	});
});

/* GET  by ID*/
router.get('/customers/:id', function(req, res, next) {
	Customers.findOne({'id': req.params.id},function(err, doc){
		if(!err) {
			res.json(doc);
		}
	});
});

/* DELETE a CUSTOMER by ID*/
router.delete('/customers/:id',function(req, res, next) {
	Customers.remove({'id': req.params.id},function(err, doc){
		if(!err) {
			res.send("deleted " + req.params.id);
		}
	});
});

// Add
router.post('/customers', function(req, res, next) {
	Customers.create(req.body,function(err, doc){
		if(!err) {
			res.send("created " );
		}
	});
});


module.exports = router;
