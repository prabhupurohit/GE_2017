var express = require('express');
var router = express.Router();
var Customers = require('../model/customer');

/* GET Customer home page. [http://localhost:3000/customers] */
router.get('/', function(req, res, next) {
	Customers.find({},function(err, docs){
		if(!err) {
			 res.render('customers', { title: 'Customers', customers: docs });
		}
	});
});

/* GET Customer home page. [http://localhost:3000/customers] */
router.get('/:id', function(req, res, next) {
	Customers.findOne({'id': req.params.id},function(err, doc){
		if(!err) {
			 res.render('customerDetails', { title: 'Customer Details', customer: doc });
		}
	});
});

module.exports = router;
