RWD
Banu Prakash C
banuprakashc@yahoo.co.in
------------------------

Adv. JS, HTML 5, CSS3, Bootstrap, nodeJs, Ang 1 and Ang2 
--------------------------------------------------------


Sublime Text 3
NodeJS 6.x
MongoDB Community Server msi

-----------------------------

JavaScript
	scripting language, event driven runs on script engine

	JS Script engine:
	Built using C/C++
	V8 ---> google [ Chrome / nodeJS]
	SpiderMonkey --> Acrobat / Safari
	IonMonkey ---> FireFox
	Chakra ---> IE

	Built using Java
	Nashhorn

	-----------

	a.js

	var first = 10;

	function test ( ) {
		var second = 20;
			if(second > 10) {
				var third = 30;
				fourth = 40;
			}
		console.log(first); // 10 global
		console.log(second); // 20 
		console.log(third); // 30 [ hoisting --> no block level var in ES5]
		console.log(fourth); // 40 [ fourth becomes a global var]
	}


	test();
		console.log(first);
		console.log(fourth);
-------------------------------------

function test ( ) {
	var x = 10	; 
	return	
		x;
}

console.log(test()); // undefined

JS engine does semi-colon insertion

-------------------------------------

Functions in jS

functions in JS are Function objects

var add = new Function("x", "y", "return x + y");

console.log(add(3,5));

function add( x, y ) {
	return x + y;
}


var add = function(x,y) {
		return x + y;
}

----------------------------------------

Pure-functions

High-order functions
	1) Functions which accept other functions as arguments
	2) functions which return a function
	Useful for Functional style of programming


	OOP has methods which work on the state of object
	Functional style of programming is not coupled to state of object

	1) map
		take a collection and return a modified collection

	2) filter
		filter contents based on predicate
	3) reduce
		sum , count, max
	4) sort

	5) forEach


	print(get) {
		 get(i);
	}
------------------------------------------------------------------------

	// pure function
	function add(x, y) {
		return x + y;
	}


	function adder(x) {
		return function(y) {
			return x + y;
		}
	}

	var fiveAdder = adder(5);

	console.log(fiveAdder(2)); // 7


	var tenAdder = adder(10);
	console.log(tenAdder(2)); // 12


	function greeting(msg, name) {
		console.log (msg + " " + name);
	}

	greeting("Good Day", "Smith");
	greeting("Good Day", "Peter");
	greeting("Good Day", "Roger");

	function greeting(msg) {
		return function(name) {
			console.log (msg + " " + name);
		}
	}

	var morningGreet = greeting("Good morning ");
	console.log(morningGreet("Smith"));
	console.log(morningGreet("Peter"));
--------------------------------------------------------

OOP with JS
-----------
Different ways of creating objects in JS:
1) 

var obj = new Object();
obj.id = 10;
obj.getData = function() {
		return this.id;
}
2) 

var nobj = Object.create(obj); // factory method
nobj.name = "Gopal";

3) JSON object
	JavaScript Object notation
	understands string, number, boolean, object, undefined  , null
	uses key:value pair
	var x ; // undefined
	var x = null; // null

	{} for object
	[] for collection

	var products = [
		{"id":1, "name" : "motoG", "category" : "mobile", "price": 12999.00},
		{"id":2, "name" : "Sony", "category" : "tv", "price": 92999.00},
		{"id":3, "name" : "iPhone7", "category" : "mobile", "price": 72999.00},
		{"id":1, "name" : "seagate hdd", "category" : "computer", "price": 999.00}

	];

	filter only mobile

	---------

	var obj = {
		"x" : 15,
		"first" : function() {
			console.log(this.x);
		},
		"second" : function(fn) {
			fn();
		}
	};

	obj.first(); // 15

	obj.second(obj.first); //expecting 15

-------
	var obj = {
		"x" : 15,
		"first" : function(a,b) {
			console.log(this.x);
		},
		"second" : function(fn) {
			//fn.call(obj, 1,4); 
			// fn.apply(obj, [1,4]);
			fn();



		}
	};

	obj.first(); // 15

	//obj.second(obj.first); //expecting 15
	obj.second(obj.first.bind(obj)); 

-------------------------------------------------------

4) Constructor Pattern

	function Mobile(id, name){
		this.id = id;
		this.name = name;
		this.details = function() {

		}
	}

	Mobile(); // wrong
	new Mobile();

	a) Object owned instance methods
	b) class owned instance methods
	c) class methods [ static ]


	Object owned instance methods:
	function Mobile(id, name){
		this.id = id;
		this.name = name;
		this.details = function() {

		}
	}

	var m1 = new Mobile(1,"A");
	var m2 = new Mobile(2,"B");

	---
	class owned instance methods

	function Mobile(id, name){
		this.id = id;
		this.name = name;
	}

	Mobile.prototype.details = function() {
		// context
	}

	Mobile.sample = function() {
		// no context == > static
	}

	var m1 = new Mobile(1,"A");
	var m2 = new Mobile(2,"B");	


	String.prototype.doTask = function() { return "<font color='red'>" + this + "</font>";   }
----------------------------------------------------------------------------------------------

IIFE in JavaScript
Immedietly Invoke Function Expresssion (Self-invoking)

(function() {
	
})();

JS Design Pattern:
1) module pattern
2) factory
3) observer
4) chain
5) memoize
6) singleton


 module pattern:
 Provides the encapsulation feature to JS [ Visbility ]

 var ShoppingCart = (function add() {
 	var cart = [];

 	function addItem(item) {
 		cart.add(item);
 	}

 	function getItems() {
 		return cart;
 	}

 	return 	{
 		"add" : addItem,
 		"getAll" : getItems
 	}
 })();


ShoppingCart.add({});
var collection = ShoppingCart.getAll();
ShoppingCart.cart; // error

----------------

Factory Pattern: 
	isolates the complexity involved in creating objects

	Document.getSingleDocument();

	DriverManager.getConnection(URL);

	------


	new Date;
	new Date();
-------------------------------------------------

	memoize pattern is based on closure

cache[37] =34534345345;

cache[12] = 33555;

-----------------------------

chain of responsibility
-----------------------

observer Pattern:

Singleton pattern

var Singleton = (function() {
	var instance = null;
	function Monitor() {
		//code
	}

	function createInstance() {
		if(instance == null) {
			instance = new Monitor();
		}
		return instance;
	}

	return {
		"create": createInstance();
	}
})();

var instance = Singleton.create();
Singleton.create();