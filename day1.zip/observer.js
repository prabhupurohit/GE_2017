var subject = {
	observers :{},

	subscribe : function(event, fn){
		this.observers[event] = this.observers[event] || [];
		this.observers[event].push(fn);
	},

	notify : function (event, data) {
		this.observers[event].forEach(function(fn){
			fn(data);
		});
	}
}