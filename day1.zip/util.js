function forEach(elems, action) {
    for (var i = 0; i < elems.length; i++) {
        action(elems[i]);
    }
};

function map(elems, mappingFn) {
        var result = [];
        forEach(elems, function(d) {
            result.push(mappingFn(d));
        });
        return result;
    };

function filter(elems, predicate) {
        var result = [];
        forEach(elems, function(d) {
            if (predicate(d)) {
                result.push(d);
            }
        });
        return result;
};
