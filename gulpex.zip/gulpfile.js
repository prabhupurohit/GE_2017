var gulp = require('gulp');
var gutil = require('gulp-util');
var jshint = require('gulp-jshint');


gulp.task('default', function() {
	return gutil.log('gulp is running');
});



// configure the jshint task
gulp.task('jshint', function() {
  return gulp.src('src/**/*.js')
    .pipe(jshint())
    .pipe(jshint.reporter('jshint-stylish'));
});

// configure which files to watch and what tasks to use on file changes
gulp.task('watch', function() {
  gulp.watch('src/**/*.js',['jshint']);
});