"use strict";

exports.map = function(elements, mapper) {
	let result = [];
	elements.forEach(function(elem) {
		result.push(mapper(elem));
	});
	return result;
};