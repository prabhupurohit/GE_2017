var map = require("./a").map;

var data = [3,6,7,88];

var result = map(data, function(e) {
	return e * 2;
});

result.forEach(function(elem){
	console.log(elem);
});