module.exports = {

	'secret': 'secret123',
	'database': 'mongodb://localhost:27017/test'

};