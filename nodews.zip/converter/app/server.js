var http = require('http');
var url = require('url');
var converter = require('./converter'); // our module

//  http://localhost:3000/rgbToHex?red=255&green=0&blue=100
// http://localhost:3000/hexToRgb?hex=ff00ff
var server = http.createServer(function(req, res) {
	var pathname = url.parse(req.url).pathname;
	var query = url.parse(req.url,true).query;

	if(pathname.substring(1) === 'rgbToHex') {
		res.end(converter.rgbToHex(parseInt(query.red), 
			parseInt(query.green), 
			parseInt(query.blue)));

	} else if(pathname.substring(1) === 'hexToRgb') {
		res.end(converter.hexToRgb(query.hex).toString());
	}
});

server.listen(3000);