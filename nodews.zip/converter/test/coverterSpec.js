var converter = require('../app/converter');
var expect = require('chai').expect;
//assemble
describe('converter tests',function(){
	// test spec
	it('should convert rgb to hex', function() {
		var result = converter.rgbToHex(255,0,0);
		expect(result).to.be.equal("ff0000");
		result = converter.rgbToHex(0,255,0);
		expect(result).to.be.equal("00ff00");
	});

	// test spec
	it('should convert hex to rgb', function() {
		var result = converter.hexToRgb("ff0000");
		expect(result).to.be.deep.equal([255,0,0]);
 	});
});