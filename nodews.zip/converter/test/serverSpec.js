var request = require('request');
var expect = require('chai').expect;
//assemble
describe('server converter tests',function(){
	// test spec
	it('should convert rgb to hex', function(done) {
		var url = "http://localhost:3000/rgbToHex?red=255&green=0&blue=0";
		request(url,function(error, response, body){
				expect(body).to.be.equal("ff0000");
				done();
		});
	});

	// test spec
	it('server should convert hex to rgb', function(done) {
		var url = "http://localhost:3000/hexToRgb?hex=ff00ff";
		request(url,function(error,   response, body){
				expect(body).to.be.equal("255,0,255");
				done();
		});
   	});
});