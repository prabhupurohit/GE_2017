var data = [3,6,8,5,12,51];

		var forEach = (elems, action) => {
			for(var i = 0; i < elems.length; i++) {
				action(elems[i]);
			}
		}

 	var  map = (elems, mappingFn) => {
			var result = [];
			forEach(elems,  (d) => {
				result.push(mappingFn(d));
			});
			return result;
		}
var op = map(data, (e) => { return e * 2; });

forEach(op, console.log); 