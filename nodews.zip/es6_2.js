class Product {

	constructor(id, name, price) {
		this.id = id;
		this.name = name;
		this.price = price;
	}

	getDetails() {
		return this.id + ", " + this.name + ", " + this.price;
	}
}

var p1 = new Product(1,"A",4545.66);
console.log(p1.getDetails());