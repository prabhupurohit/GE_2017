function doTask() {
		return new Promise(function(resolve, reject) {
			setTimeout(function() {
				reject(":-) Completed ");
			} , 1000);
		});
}

doTask().then(function(data){
	console.log("SUCESS " + data);
},
function(data) {
	console.log("ERROR " + data);
});