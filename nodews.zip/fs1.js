// get fs module
var fs = require('fs');

var content = fs.readFileSync('fs1.js');

console.log(content.toString());