// get fs module
var fs = require('fs');

var content =  "";

fs.readFile('fs1.js', function(err, data) {
	content += data;
	console.log("INSIDE: " + content.toString());
});

console.log("OUTSIDE: " + content.toString());