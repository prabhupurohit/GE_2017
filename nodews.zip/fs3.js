// get fs module
var fs = require('fs');

var stream = fs.createReadStream("fs1.js");

stream.on("data", function(chunk){
console.log("chunk: " + chunk.toString());
});

stream.on("end", function(chunk){
console.log("DONE");
});