NodeJS

Event Driven:
console.log("Start");

function sample() {
		setTimeout(function() {
			console.log("Hello !!!")
		}, 2000);
}

function doTask() {
		setInterval(function() {
			console.log("Hi !!!")
		}, 500);
}

sample();
doTask();
console.log("Bye!!!");

--------
Install NodeJS

Why NodeJS?
	Event Driven, non-blocking IO

Why People are moving to NodeJS?
 1) Paypal
 	Productivity , Performance
 2) Walmart
 	2014 Blackfriday
 3) LinkedIn

 Where can i Use nodeJS?
 	1) nonBlocking IO
 		netflix
 	2) SPA
 	3) Dashboard
-----------------------------------

ES6 ES2015 features:

1) supports block level variables and constants
let and const are block level scope

function test() {
		if( cond ) {
			let x = 10;
			const PI = 3.14159;
		}
}

2) Arrow Operator

var add = function(x, y) {
		return x + y;
}


var sub = (x,y) => { return x - y; }

var sub = (x,y) => x - y ;

3) New String literal:  ` `

var style = {
	width:'200px',
	height:'400px',
	color:'red'
}


var el = `<div>
			<p style="width:${style.width}; height: ${style.height}">
				Hello World
			</p>
	</div>`;


4) introduced class

5) Promise API

Sync call

var result = doTask();
next line

With Promise API

doTask().then(function() { }, function error() { });
-------------------------------------------------------------------------

Benchmark:
ab -n 1000 -c 100 http://localhost:3000/

-------------------------------------

REPL
	ReadEvalPrintLoop
-----------------------------------
fs, http, repl, net, cluster, os modules:

nodeJS uses CommonModuleJS

Module Pattern:
a.js
(function() { })();

b.js
(function() { })();

html needs them
<script src ="a.js"></script>
<script src ="b.js"></script>

Asynchronous Module loading
a) RequireJS
b) CommonJS
c) SystemJS

Node JS CommonJS for AMD

a.js

exports.add = function() {
	
}

exports.test = function test() {
	
}


b.js
if(x){
	var test = require('./a').test;
}
var add = require('./a').add;


var sdf = require('./a').add;

-----

NPM -- > node package manager
	to create, publish and import node packages

 npm uses package.json for package maangement:

 package.json

 {
 	"name":
 	"author":

 	"dependencies": {
 		"mysql" : "3.1.15",
 		"blue-bird": "^2.1.1",
 		"passport" : "~2.0.1"
 	}
 }

 JavaScript and unit testing

 Unit testing frameworks:
 1) JASMINE
 	Prefer for client side
 2) MOCHA
 	Prefer for server side

 Testing is all about AAA's
 Assemble Action Assert

MOCHA provides framework for Assemble and Action and execute tests, it does not contain assertion library

Some of the assertion libraries available are:
chai
shouldjs 


converter:/> npm install --save-dev mocha chai request

installs into node_modules folder

npm i -g mocha

mocha --reporter spec

npm config set proxy http://proxy.company.com:8080
npm config set https-proxy http://proxy.company.com:8080

------------------------------------

MongoDB Humungous Database is a NoSQL database

RDBMS 										MongoDB
Database 								Database
Tables 									Collections
Row 									Document
columns 								fields
										BSON [Binary Script Object notation]

1) Start Mongodb database server

$ mongod --dbpath ./data

$ mongoimport --file customers.json --db my_db --collection customers --drop

 