var repl = require('repl');

var net = require('net');

var mood = function () {
	var data = [":->",":-(",":-)",";-|"];

	return data[ Math.floor(Math.random()*data.length) ];
}

var prompt = repl.start("ge:/>");
prompt.context.mood = mood;

var server = net.createServer(function(socket){
	// telnet localhost 1234
	var remotePrompt = repl.start("GE:/>", socket);
	remotePrompt.context.mood = mood;
});

server.listen(1234);
