// facebook app settings
module.exports = {
	'appID' : '1600137293549207',
	'appSecret' : 'ad754030d093971a743808249d2e8267',
	'callbackUrl' : 'http://localhost:3000/login/facebook/callback'
}