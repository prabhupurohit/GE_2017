// twitter app settings
module.exports = {
	'apikey' : 'S39Xo2q3kHxE3Yv8x9aWYxWOS',
	'apisecret' : 'c9vRQW8YvG4ieg5pWVGO0YI3w4If9GhugzLNDFMJBCDmnH4l5g',
	'callbackUrl' : 'http://127.0.0.1:3000/login/twitter/callback'
}