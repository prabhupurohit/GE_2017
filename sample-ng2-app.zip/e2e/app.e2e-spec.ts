import { SampleNg2AppPage } from './app.po';

describe('sample-ng2-app App', function() {
  let page: SampleNg2AppPage;

  beforeEach(() => {
    page = new SampleNg2AppPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
