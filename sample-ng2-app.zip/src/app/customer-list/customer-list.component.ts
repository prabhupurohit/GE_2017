import { Component, OnInit } from '@angular/core';
import {Customer} from '../model/customer';

@Component({
  selector: 'customer-list',
  templateUrl: './customer-list.component.html',
  styleUrls: ['./customer-list.component.css']
})
export class CustomerListComponent implements OnInit {
  customers: Customer[];

  constructor() { }

  ngOnInit() {
  	this.customers = [
        { "id": 1, "firstName": "Ross", "lastName": "Geller", "gender": "male", "address": "NY" },
        { "id": 2, "firstName": "Joey", "lastName": "Tribuanni", "gender": "male", "address": "NY" },
        { "id": 3, "firstName": "Monica", "lastName": "Geller", "gender": "female", "address": "NY" },
        { "id": 4, "firstName": "Rachel", "lastName": "Green", "gender": "female", "address": "NY" },
        { "id": 5, "firstName": "Chandler", "lastName": "Bing", "gender": "male", "address": "NY" },
        { "id": 6, "firstName": "Phoebe", "lastName": "Buffay", "gender": "female", "address": "NY" }
    ];
  }

}
