import { Component, OnInit } from '@angular/core';
import {Customer} from '../model/customer';

@Component({
  selector: 'customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {
  customer: Customer;
  constructor() { }

  ngOnInit() {
  	this.customer = new Customer(1,"Smith","Jones","male","some address");
  }

  deleteCustomer(id:number){
  	console.log(id + " deleted !!!!!");
  }
}
